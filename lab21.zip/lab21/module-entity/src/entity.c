#include "entity.h"
/**
 * @file lib.c
 * @brief Файл з реалізацією функцій
 *
 * @author Belchynska K.
 * @date 02-march-2021
 * @version 1.0
 */




void printInst(struct Instrument * instrument){
    printf("%s", instrument->firm);
    printf("\tFirm: %s\n", instrument->firm);
    printf("\tYear: %d\n", instrument->year);
    printf("\tSize: %f\n\n", instrument->size);
}